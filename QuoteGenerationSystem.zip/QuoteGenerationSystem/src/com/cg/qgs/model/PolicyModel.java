package com.cg.qgs.model;

public class PolicyModel {

	private long policyNumber;
	private long policyPremium;
	private long accountNumber;
	private String businessSegment;

	public PolicyModel() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PolicyModel [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium + ", accountNumber="
				+ accountNumber + ", businessSegment=" + businessSegment + "]";
	}

	public PolicyModel(long policyNumber, long policyPremium, long accountNumber, String businessSegment) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		this.businessSegment = businessSegment;
	}

	public long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public long getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(long policyPremium) {
		this.policyPremium = policyPremium;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBusinessSegment() {
		return businessSegment;
	}

	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}

}
