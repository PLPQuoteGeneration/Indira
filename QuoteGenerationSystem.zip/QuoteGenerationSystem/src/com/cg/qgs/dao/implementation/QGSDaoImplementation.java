package com.cg.qgs.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.qgs.dao.QGSDao;
import com.cg.qgs.dao.QueryMapper;
import com.cg.qgs.exception.QGSException;
import com.cg.qgs.model.AccountBean;
import com.cg.qgs.model.LoginBean;
import com.cg.qgs.model.PolicyModel;
import com.cg.qgs.utility.JdbcUtility;

public class QGSDaoImplementation implements QGSDao {
	Connection connection = null;

	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;

	@Override
	public List<LoginBean> loginValid(String username, String password) throws QGSException {

		ResultSet resultSet = null;
		List<LoginBean> list = null;
		connection = JdbcUtility.getConnection();

		try {
			list = new ArrayList<>();
			preparedStatement = connection.prepareStatement(QueryMapper.loginValidation);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				String userName = resultSet.getString(1);
				String roleCode = resultSet.getString(3);

				LoginBean bean = new LoginBean();
				bean.setUsername(userName);
				bean.setRoleCode(roleCode);

				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			resultSet.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public boolean getValidUsername(String userName) throws QGSException {
		boolean userFlag = false;
		List<LoginBean> list1 = null;
		connection = JdbcUtility.getConnection();
		list1 = new ArrayList<>();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.userValidation);

			preparedStatement.setString(1, userName);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				String profUserName = resultSet.getString(1);
				LoginBean bean = new LoginBean();
				bean.setUsername(profUserName);
				list1.add(bean);
			}
			if (list1.isEmpty()) {
				userFlag = true;

			} else {
				userFlag = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userFlag;
	}

	@Override
	public int addProfile(LoginBean bean) throws QGSException {
		int result = 0;
		connection = JdbcUtility.getConnection();

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.addProfile);
			preparedStatement.setString(1, bean.getUsername());
			preparedStatement.setString(2, bean.getPassword());
			preparedStatement.setString(3, bean.getRoleCode());

			result = preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				e.printStackTrace();
			}

		}
		return result;
	}

	@Override
	public long addAccount(AccountBean accountBean) throws QGSException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		long accountNumber = 0;
		try {

			preparedStatement = connection.prepareStatement(QueryMapper.addAccount);

			preparedStatement.setString(1, accountBean.getInsuredName());
			preparedStatement.setString(2, accountBean.getInsuredStreet());
			preparedStatement.setString(3, accountBean.getInsuredCity());
			preparedStatement.setString(4, accountBean.getInsuredState());
			preparedStatement.setLong(5, accountBean.getInsuredZip());
			preparedStatement.setString(6, accountBean.getUserName());

			result = preparedStatement.executeUpdate();

			if (result == 1) {

				preparedStatement = connection.prepareStatement(QueryMapper.getAccountNumber);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				accountNumber = resultSet.getLong(1);
			} else {

			}

		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();

			} catch (SQLException e) {
				
				try {
					connection.rollback();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();

			} catch (SQLException e) {
				
				try {
					connection.rollback();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				e.printStackTrace();
			}

		}

		return accountNumber;
	}

	@Override
	public List<PolicyModel> checkAccountNumber(long accountNumber) throws QGSException {
		List<PolicyModel> list = new ArrayList<>();

		connection = JdbcUtility.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.getDetails);
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				long policyNumber = resultSet.getLong(1);
				long policyPremium = resultSet.getLong(2);
				long accountNumber1 = resultSet.getLong(3);
				String businessSegment = resultSet.getString(4);
				PolicyModel policyModel = new PolicyModel();
				policyModel.setPolicyNumber(policyNumber);
				policyModel.setPolicyPremium(policyPremium);
				policyModel.setAccountNumber(accountNumber1);
				policyModel.setBusinessSegment(businessSegment);
				list.add(policyModel);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}  finally {
			try {
				preparedStatement.close();

			} catch (SQLException e) {
				
				try {
					connection.rollback();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();

			} catch (SQLException e) {
				
				try {
					connection.rollback();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				e.printStackTrace();
			}

		}
		return list;
	}

}
