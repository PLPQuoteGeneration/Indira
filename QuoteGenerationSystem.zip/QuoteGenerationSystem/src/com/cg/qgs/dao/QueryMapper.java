/**
 * 
 */
package com.cg.qgs.dao;

/**
 * @author nsekhar
 *
 */
public interface QueryMapper {

	public static final String loginValidation = "select * from userrole where username = ? and password = ?";
	public static final String userValidation = "select username from userrole where username = ?";
	public static final String addProfile = "insert into userrole values(?,?,?)";
	public static final String addAccount = "insert into accounts values(account_number_seq.nextval,?,?,?,?,?,?)";
	public static final String getAccountNumber = "select account_number_seq.currval from dual";
	public static final String getDetails="select * from policy where account_number=?";
}
