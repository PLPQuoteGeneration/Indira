/**
 * 
 */
package com.cg.qgs.service.implementation;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.qgs.dao.QGSDao;
import com.cg.qgs.dao.implementation.QGSDaoImplementation;
import com.cg.qgs.exception.QGSException;
import com.cg.qgs.model.AccountBean;
import com.cg.qgs.model.LoginBean;
import com.cg.qgs.model.PolicyModel;
import com.cg.qgs.service.QGSService;

/**
 * @author nsekhar
 *
 */
public class QGSServiceImpl implements QGSService {

	QGSDao dao = new QGSDaoImplementation();
	
	@Override
	public List<LoginBean> loginValid(String username, String password)throws QGSException {
		// TODO Auto-generated method stub
		return dao.loginValid(username,password);
	}

	@Override
	public boolean getValidUsername(String userName) throws QGSException {
		// TODO Auto-generated method stub
		return dao.getValidUsername(userName);
	}

	@Override
	public int addProfile(LoginBean bean) throws QGSException {
		// TODO Auto-generated method stub
		return dao.addProfile(bean);
	}

	@Override
	public long addAccount(AccountBean accountBean) throws QGSException {
		// TODO Auto-generated method stub
		return dao.addAccount(accountBean);
	}

	@Override
	public boolean validName(String insuredName) throws QGSException {
		String NameRegEx="^[a-zA-Z\\s]{3,30}$";
		return Pattern.matches(NameRegEx, insuredName);
	}

	@Override
	public boolean validStreet(String insuredStreet) throws QGSException {
		String streetRegEx="^[a-zA-Z\\s]{3,40}$";
		return Pattern.matches(streetRegEx, insuredStreet);
	}

	@Override
	public boolean validCity(String insuredCity) throws QGSException {
		String cityRegEx="^[a-zA-Z\\s]{3,15}$";
		return Pattern.matches(cityRegEx, insuredCity);
	}

	@Override
	public boolean validState(String insuredState) throws QGSException {
		String stateRegEx="^[a-zA-Z\\s]{3,15}$";
		return Pattern.matches(stateRegEx, insuredState) ;
	}

	@Override
	public boolean validZip(long insuredZip) throws QGSException {
		String stateRegEx="^[1|2|3|4|5|6|7|8|9]{1}[0-9]{4}$";
		return Pattern.matches(stateRegEx, String.valueOf(insuredZip));
	}

	@Override
	public Boolean accountValidation(long accountNumber) throws QGSException {
	String accountNoRegEx="^[1|2|3|4|5|6|7|8|9]{1}[0-9]{9}$";
		return Pattern.matches(accountNoRegEx, String.valueOf(accountNumber));
	}

	@Override
	public List<PolicyModel> getDetails(long accountNumber) throws QGSException {
		
		return dao.checkAccountNumber(accountNumber);
	}

}
